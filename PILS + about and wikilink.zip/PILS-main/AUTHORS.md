* Charles McNamara - @Maascharlie  
* Maarten Janzen - @kaggleidk
* Kelly Wolters  - @kelly2110 

